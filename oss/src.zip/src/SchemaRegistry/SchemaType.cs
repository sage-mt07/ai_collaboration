﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsqlDsl.SchemaRegistry;

/// <summary>
/// Schema type (Avro only)
/// </summary>
public enum SchemaType
{
    Avro
}